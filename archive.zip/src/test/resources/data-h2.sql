
-- Disabled placeholders, NOT login credentials. Authentication is not implemented here.
INSERT INTO staff_account (staff_id,username,password_hash,name,level,active) VALUES
 (1,'demo_staff','!DISABLED_DEMO_ACCOUNT','測試店員','STAFF',FALSE),
 (2,'demo_manager','!DISABLED_DEMO_ACCOUNT','測試店長','MANAGER',FALSE);

INSERT INTO member (phone,name,address,note) VALUES
 ('0900000001','測試會員甲','測試市測試路一號（虛構地址）','僅供測試，請勿配送');

-- Opening stock before the sample orders below.
INSERT INTO inventory (inventory_id,name,base_unit,pack_unit,per_pack,book_qty,safety_stock) VALUES
 (1,'中杯紙杯','個','袋',50,100,20),
 (2,'大杯紙杯','個','袋',50,100,20),
 (3,'紅茶包','包','盒',20,100,20),
 (4,'綠茶包','包','盒',20,100,20),
 (5,'奶料','份',NULL,NULL,100,20),
 (6,'珍珠','份',NULL,NULL,100,20),
 (7,'茶凍','份',NULL,NULL,100,20),
 (8,'芒果冰沙料','份',NULL,NULL,8,10);

-- 021：配方只記材料清單（中大杯共用、不含紙杯），份量寫在 recipe_steps；茶凍是半成品
INSERT INTO product (product_id,name,category,base_price,large_extra,hot_allowed,recipe_steps,min_view_level) VALUES
 (1,'經典紅茶','茶類',25,5,TRUE,'依杯型備杯，加入紅茶，依客製甜度與冰量調製。','TRAINEE'),
 (2,'茉香綠茶','茶類',25,5,TRUE,'依杯型備杯，加入綠茶，依客製甜度與冰量調製。','TRAINEE'),
 (3,'經典奶茶','奶茶',40,10,TRUE,'依杯型備杯，混合紅茶與一份奶料，依客製規格調製。','TRAINEE'),
 (4,'珍珠奶茶','奶茶',50,10,TRUE,'依杯型備杯，加入一份珍珠、紅茶與一份奶料。品項已含珍珠，額外點珍珠代表再加一份。','TRAINEE'),
 (5,'芒果冰沙','冰沙',55,10,FALSE,'依杯型備杯，加入一份冰沙料，以固定正常甜度與正常冰量攪打。','STAFF');

INSERT INTO prep_item (prep_id,name,steps) VALUES (1,'茶凍','紅茶煮好後加吉利丁冷藏定型。');
INSERT INTO prep_item_ingredient (prep_id,inventory_id) VALUES (1,3);
ALTER TABLE prep_item ALTER COLUMN prep_id RESTART WITH 2;

INSERT INTO product_recipe (product_id,inventory_id,prep_id,sort_order) VALUES
 (1,3,NULL,1),
 (2,4,NULL,1),
 (3,3,NULL,1),(3,5,NULL,2),
 (4,3,NULL,1),(4,5,NULL,2),(4,6,NULL,3),
 (5,8,NULL,1);

INSERT INTO topping (topping_id,name,price,inventory_id,prep_id) VALUES
 (1,'珍珠',10,6,NULL),(2,'茶凍',10,NULL,1);

-- JSON contract examples, not an implemented rules engine.
INSERT INTO conflict_rule (rule_id,rule_type,condition_json,action_json,message) VALUES
 (1,'FORBID','{"temperatureIn":["WARM","HOT"]}','{"forbidToppingIds":[2]}','溫熱飲不可加茶凍'),
 (2,'AUTO_ADJUST','{"category":"冰沙"}','{"set":{"temperature":"COLD","sugar":"NORMAL","ice":"NORMAL"},"lockFields":["temperature","sugar","ice"]}','冰沙固定冰量與甜度'),
 (3,'AUTO_ADJUST','{"temperatureIn":["WARM","HOT"]}','{"set":{"ice":"NONE"},"lockFields":["ice"]}','溫熱飲不加冰塊'),
 (4,'MAX_COUNT','{"always":true}','{"field":"toppingIds","maxDistinct":3}','額外加料最多三種');

-- Fixed historical fixture, not an automatic opening for today's business.
INSERT INTO daily_shift (business_date,status,opened_by,opened_at,petty_cash,roles_json)
 VALUES ('2026-10-28','OPEN',1,'2026-10-28 09:00:00',2000,
 '[{"staffId":1,"role":"CASHIER"},{"staffId":2,"role":"BAR"}]');

INSERT INTO pos_order (order_id,order_no,business_date,member_phone,source,payment,total,received_cash,change_cash,status,created_by,created_at,paid_amount,refunded_amount) VALUES
 (1,'DEMO-20261028-001','2026-10-28',NULL,'TAKE_OUT','CASH',130,200,70,'PENDING',1,'2026-10-28 10:00:00',130,0),
 (2,'DEMO-20261028-002','2026-10-28',NULL,'TAKE_OUT','LINE_PAY',55,NULL,NULL,'MAKING',1,'2026-10-28 10:05:00',55,0),
 (3,'DEMO-20261028-003','2026-10-28',NULL,'TAKE_OUT','LINE_PAY',0,NULL,NULL,'CANCELLED',1,'2026-10-28 10:10:00',25,25),
 (4,'DEMO-20261028-004','2026-10-28',NULL,'DINE_IN','LINE_PAY',0,NULL,NULL,'CANCELLED',1,'2026-10-28 10:15:00',60,60);

-- Order 1: two large red teas + pearl at 40 each, plus one medium milk tea + jelly at 50.
-- Order 3: cancelled before making, all stock returned.
-- Order 4: made then wasted, refunded but stock NOT returned; photo optional.
INSERT INTO order_item (item_id,order_id,product_id,product_name,size,temperature,sugar,ice,qty,unit_price,status,reason,approved_by,note) VALUES
 (1,1,1,'經典紅茶','L','COLD','HALF','LESS',2,40,'PENDING',NULL,NULL,'同規格兩杯'),
 (2,1,3,'經典奶茶','M','COLD','NORMAL','NORMAL',1,50,'PENDING',NULL,NULL,NULL),
 (3,2,5,'芒果冰沙','M','COLD','NORMAL','NORMAL',1,55,'MAKING',NULL,NULL,NULL),
 (4,3,2,'茉香綠茶','M','COLD','NONE','NONE',1,25,'CANCELLED','測試：尚未製作，客人取消',NULL,NULL),
 (5,4,4,'珍珠奶茶','L','COLD','HALF','LESS',1,60,'WASTED','測試：已製作棄單',2,NULL);

INSERT INTO order_item_topping (item_id,topping_id,topping_name,price_at_order) VALUES
 (1,1,'珍珠',10),(2,2,'茶凍',10);

-- Apply the NET stock effects of the fixtures exactly once inside this transaction.
-- Cancelled item 4 has zero net stock effect; wasted item 5 remains deducted.
UPDATE inventory SET book_qty=book_qty-2 WHERE inventory_id=1;
UPDATE inventory SET book_qty=book_qty-3 WHERE inventory_id=2;
UPDATE inventory SET book_qty=book_qty-4 WHERE inventory_id=3;
UPDATE inventory SET book_qty=book_qty-2 WHERE inventory_id=5;
UPDATE inventory SET book_qty=book_qty-3 WHERE inventory_id=6;
UPDATE inventory SET book_qty=book_qty-1 WHERE inventory_id=7;
UPDATE inventory SET book_qty=book_qty-1 WHERE inventory_id=8;
-- Fictional costs from migration 006; test-only seed.
UPDATE inventory SET unit_cost=CASE inventory_id WHEN 1 THEN 0.80 WHEN 2 THEN 1.00 WHEN 3 THEN 3.00 WHEN 4 THEN 3.00 WHEN 5 THEN 6.00 WHEN 6 THEN 3.00 WHEN 7 THEN 2.50 WHEN 8 THEN 12.50 END WHERE inventory_id BETWEEN 1 AND 8;

UPDATE order_item SET refund_amount=qty*unit_price WHERE status IN ('CANCELLED','WASTED');

-- 015：預設排班標籤（編號 1～4）
INSERT INTO schedule_tag (tag_id, name, description) VALUES
 (1,'開班',NULL),(2,'支援',NULL),(3,'收班',NULL),(4,'休息','這段班可以中間休息半小時');
ALTER TABLE schedule_tag ALTER COLUMN tag_id RESTART WITH 5;
