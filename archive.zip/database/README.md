# POS 資料庫與測試資料

依 `drinkshop_pos_spec2.pdf` 的 10 張核心表準備，資料庫為 `drinkshop_pos`，MySQL 8.0.16 以上。
目前 POS API 已接上 drinkshop_pos；使用明確 SQL，不使用 Hibernate 自動改表。前端已提供點餐與訂單介面，新單已記錄原料成本快照。
後端使用方式參閱 `docs/POS_API.md`。

## 雲端共用資料庫（Aiven）

全組共用的資料庫架在 Aiven，資料庫名稱 `drinkshop_pos`，已依下列順序建好。**平常不需要執行這些 SQL**；只有雲端資料庫需要重建，或要在自己電腦建練習用資料庫時才執行，而且由一位組員執行一次即可。

用 Workbench 連 Aiven：Hostname／Port／Username 見共用文件，SSL 分頁選 Require，Default Schema 留空。出現 8.4 版本相容警告時按 Continue Anyway。

Workbench 預設開啟 Safe Updates，會擋下 006 的 UPDATE（Error 1175）。執行 006 前先在同一分頁執行 `SET SQL_SAFE_UPDATES = 0;`，或到 Preferences → SQL Editor 取消 Safe Updates 後重新連線。

## 執行順序

在 MySQL Workbench 中依序開啟並執行：

1. `001_schema.sql`：建立資料庫及 10 張表。
2. `002_demo_data.sql`：以交易加入測試資料與訂單造成的庫存變動。
3. `004_pos_api.sql`：新增重送請求校驗與扣料快照兩欄（既有本機已套用）。
4. `005_team_er_alignment.sql`：團隊 ER 圖調整（金額小數、加料獨立主鍵、距離時間改名；既有本機已套用）。
5. `006_demo_ingredient_costs.sql`：新增每單位成本與八種原料假成本（本機已套用）。
6. `007_payment_and_wastage_workbench.sql`：收款、退款與損耗欄位。僅供新庫或經團隊同意的舊庫升級，先備份並停止所有後端，需要 CREATE/ALTER ROUTINE 權限。完整升級後重跑會跳過，部分升級會在變更前停止；不要忽略錯誤繼續。不要直接執行 `007_payment_and_wastage.sql`。共用 Aiven 已建好，不執行這些 SQL。
7. `008_member_geo_source.sql`：會員座標來源欄位，僅供本機或團隊同意後升級；不要自行對 Aiven 執行。
8. `003_verify.sql`（選用）：檢查原始範例訂單金額、庫存及配方原料參照。

`scripts/` 裡的 Python 腳本只連本機 `127.0.0.1:3306`，不能用於雲端資料庫。

007 重跑防護的本機回歸測試：`python scripts/test_workbench_migration.py --local-config <本機設定檔路徑>`。設定檔須包含本機 `spring.datasource.username/password`；不可傳 Aiven 設定。腳本僅在 127.0.0.1 建立並清除自己建立的隨機測試庫，驗證首次升級、重跑不改部分退款／未付款資料，以及部分升級時安全停止。

不使用 DROP、TRUNCATE、INSERT IGNORE 或覆蓋既有資料。資料庫已存在時第一支會失敗；請停止，不要選擇忽略錯誤繼續執行。
種子資料僅執行一次。重複執行會因唯一鍵失敗，必須停止並 rollback，不要跳過錯誤；不可單獨重跑最後的庫存 UPDATE。
MySQL 的 DDL 不具整批回滾能力；若建表中途失敗，先檢查已完成的表，不要直接重跑或刪除資料庫。

## 目前資料約定

- 一張 `pos_order` 包含多筆 `order_item`；每筆為同商品、杯型、冰甜、加料、備註及製作狀態，`qty` 可大於 1。
- 同筆明細一起取消或轉損耗。只取消其中一杯的功能，需先拆分明細及其加料，尚未實作。
- `unit_price` 是含所有加料的每杯最終價。明細金額 = `qty * unit_price`；`price_at_order` 僅核對加價，不得再加一次。
- `product.base_price` 為中杯價，大杯加 `large_extra`。額外加料每種一次；半份、雙倍未納入。
- 珍奶配方已含一份珍珠；若額外選珍珠，需再扣一份，並再加價。
- `recipe_json` 使用 `M`、`L` 分開列原料 ID 及每杯用量，含紙杯；這是結構化扣料資料，製作文字另放 `recipe_steps`。
- `conflict_rule` JSON 目前只是明確範例，尚未有規則引擎，沒有啟用空泛的群組互斥規則。
- 依 spec2，會員只有一組常用地址，不保留歷史配送地址；盤點只留最近一次，沒有審核表及歷史表；沒有配方查看紀錄。
- JSON 內原料 ID 無法由一般外鍵保護，寫入時需要後端驗證，刪除原料前也需檢查。
- 額外加入商品及加料名稱快照、品項備註、訂單建立時間與編號、開班狀態、現金實收與找零，支援基本查詢與核對，不新增資料表。
- 所有金額為新台幣元，`DECIMAL(10,2)` 最多兩位小數；時間使用台灣本地時間，`duration` 為秒、`distance` 為公尺（最多兩位小數）。
- `order_item_topping.order_topping_id` 為獨立自增主鍵；`(item_id,topping_id)` 仍有唯一限制，避免同種加料重複。
- [目前 ER 圖](../docs/database-er.mmd) 包含後端必要欄位及修正後的可空白關聯。001 是歷史基礎版本，最新結構要套用 004 與 005。
- 資料庫本身沒有扣料觸發器；目前後端已在交易中完成計價、扣料、回補與 PIN 驗證，並用 requestId 與內容雜湊防止重複送單。正式日結 API 尚未實作。
- 訂單與明細的狀態一致性、總額及規則仍需後端驗證；SQL CHECK 只保護基本範圍與欄位組合。

## 假資料

全部為虛構店家與會員。5 種飲料：紅茶、綠茶、奶茶、珍奶、芒果冰沙；2 種加料：珍珠、茶凍。
8 種原料、4 條衝突規則、1 位會員、2 個員工參照及一筆固定 `2026-10-28` 的開班資料。
員工 `active=false`，密碼為不可登入的停用標記，不提供共用明碼密碼。這些只供訂單關聯使用；登入及 PIN 日後由帳號模組建立正式雜湊。
固定開班資料不是每天自動開班。另有選用的本機 demo initializer 建立 `pos_cashier`、`pos_manager` 與缺少的當日測試開班，見 API 文件；原始兩個停用帳號不變。

| 訂單 | 情境 | 金額 |
| --- | --- | --- |
| DEMO-20261028-001 | 大杯紅茶加珍珠兩杯（每杯 40）＋中杯奶茶加茶凍一杯（50）；現金 200 找 70 | 130 |
| DEMO-20261028-002 | 中杯芒果冰沙一杯，製作中 | 55 |
| DEMO-20261028-003 | 中杯綠茶一杯，未製作取消，已全額退款並回補 | 0 |
| DEMO-20261028-004 | 大杯珍奶一杯，已製作棄單，假設已全額退款；不回補，照片選填 | 0 |

基礎假資料的取消案例假設已全退；007 後 total 只表示保留品項合計，淨收款改用 paid_amount − refunded_amount，見 ../docs/PAYMENT_AND_WASTAGE.md。
007 支援取消時部分／全額退款或不退款，以及未付款接單；仍非完整金流帳務，不支援日結後退款。
現金樣本僅有正常交易；取消案例使用 LINE Pay 標記，沒有假設實際串接 LINE Pay。
運費欄位目前均為 0，不預設建議運費一定向客人收取。

測試庫存已扣除未取消訂單及已製作損耗，不扣未製作取消的綠茶。
預期庫存依 ID：98、97、96、100、98、97、99、7；冰沙料低於安全庫存可測紅燈。
預期保留營收 185 元，保留銷售 4 杯、未製作取消 1 杯、已製作損耗 1 杯。

## 後續串接前要確認

部分杯數取消的拆分方式、含加料單價、付款與退款定義、庫存不足是否阻擋、訂單狀態與日結規則，以及組員是否接受 JSON 格式與新增欄位。
POS API 使用 Boot 3／Gradle，見 API 文件。
現金 API 取消後 `change_cash` 為原找零加上人工退款的累計退還現金，`received_cash` 保留原實收；原始假資料的現金單沒有退款。

## 本機驗證（2026-10-28）

已在 MySQL 8.0.46 建立 `drinkshop_pos` 並依序執行三支 SQL。
確認 10 張 InnoDB 表、5 種飲料、2 種加料、8 種原料、4 條規則及 4 張訂單。
四張訂單金額全數一致，配方 JSON 的原料參照有效。
另以配方、明細杯數及加料獨立重算庫存，與資料庫相同。
六項無效寫入測試（零杯數、熱飲有冰、損耗無授權人、不存在的加料、找零錯誤、負庫存）均被約束拒絕，測試交易沒有提交。
SQL 僅以獨立的 POS 資料庫為目標。

## 團隊 ER 圖調整（2026-10-28）

已實際套用 005；既有資料逐筆比對一致，10 張表保留。
金額改為 DECIMAL(10,2)，Java 改用 BigDecimal。資料庫有 005 前的完整 mysqldump 備份（存於忽略的 build/db-backups）。
原始整數假資料保留，實際 MySQL 測試庫另驗證 40.30 × 3 = 120.90、找零 79.35 及退款 200.25，不改寫本機假商品價格。

成本假資料、計算範例與限制見 [DEMO_COSTS.md](../docs/DEMO_COSTS.md)。可執行唯讀的 `recipe_cost_report.sql` 檢查每杯配方分解。現有資料庫仍為 10 張表，沒有調整售價或庫存。

本機已備份並套用 007 收款與損耗欄位，現有訂單筆數與庫存保留。升級說明見 [PAYMENT_AND_WASTAGE.md](../docs/PAYMENT_AND_WASTAGE.md)。

組員啟動與 007 升級步驟請見 [TEAM_QUICKSTART.md](../docs/TEAM_QUICKSTART.md)。目前已製作棄單不需店長帳號或 PIN；approved_by 記錄有效登入操作員工，舊假資料仍保留歷史值。

## 原料報廢修正（尚未套用共用庫）

`009_raw_material_wastage.sql` 新增原料損耗事件表，共用庫已建立，`application.properties` 預設啟用寫入。連到沒有這張表的資料庫時，請在 `.pos-local.properties` 設 `pos.raw-wastage.enabled=false`；設定本身不會自動建表。行為及啟用步驟見 [CLOSING_WASTAGE_FIX.md](../docs/CLOSING_WASTAGE_FIX.md)。

## 原料盤點紀錄（尚未套用共用庫）

`016_inventory_count.sql` 新增盤點紀錄表 `inventory_count`：每次盤點每項原料一列，保存當時的帳面數量、實點數量、差異與單位成本。同一支檔案也在 `inventory` 加上 `allow_decimal`（預設 TRUE），控制盤點時小單位能不能填小數，例如紙杯可設成只能填整數：`UPDATE inventory SET allow_decimal = FALSE WHERE name IN ('中杯紙杯', '大杯紙杯');`。盤點只記錄，不修改 `inventory.book_qty`；`inventory.reported_qty`／`reported_by`／`reported_at` 仍會更新成最新一次。

須由資料庫負責人先確認升級，不可自行對 Aiven 執行。預設未啟用：升級成功後，在本機未追蹤的 `.pos-local.properties` 加上 `pos.inventory-count.enabled=true` 並重新啟動後端，盤點頁才能送出。未啟用時送出盤點會回 503，不會寫入任何資料。

## 盤點紀錄改成表頭／明細（017，尚未套用共用庫）

`017_inventory_count_header.sql`：016 的 `inventory_count` 每項原料一列，同一次盤點的盤點人、時間、備註重複存。017 改成表頭 `inventory_count`（一次盤點一列）＋明細 `inventory_count_line`（每項原料一列），並把現有資料依 `request_id` 搬過去；舊表改名為 `inventory_count_016` 保留，核對筆數無誤後再手動 `DROP`（檔案最後有核對用的查詢）。

同一支檔案也把 `inventory.allow_decimal` 預設改成 FALSE，並把現有原料都改成不能填小數；需要小數的原料再個別 `UPDATE inventory SET allow_decimal = TRUE WHERE ...`。

**後端程式依 017 的結構寫入與查詢，017 執行前盤點頁會無法送出與查詢紀錄。** 請先執行 017，再部署這版後端。

## 帳面庫存規則（2026-11 起）

點餐、取消訂單、原料報廢都**不再扣或回補** `inventory.book_qty`。配方用量一定和實際有落差，帳面改以盤點為準：

- 盤點送出時，帳面改成實點數量；盤點紀錄保留盤點前的帳面與差異。
- 手動校正（`PUT /api/inventories/{id}/stock`）仍可直接改帳面。
- 點餐不再檢查原料夠不夠；訂單明細仍記錄配方的理論用量（`deducted_inventory_json`）與原料成本（`material_cost`），報廢損耗金額照算。
- 原料報廢只留紀錄（數量、原因、當時成本），不扣帳面。

不需要改資料表。

## 盤點類型（018，尚未套用共用庫）

`018_inventory_count_type.sql` 新增盤點類型：盤點時先選類型，類型決定**輸入方式**（`PACK_AND_LOOSE` 箱數＋零散／`PACK_ONLY` 只填箱數）與**要盤哪些原料**（勾「全部原料」的類型會自動包含之後新增的原料）。

- 預設只建「大盤」（全部原料、箱數＋零散）；小盤等其他類型由店長、總部在盤點頁新增。
- 類型可以停用，不能刪除；停用後不能再用來盤點，舊紀錄不受影響。
- 盤點表頭 `inventory_count` 加上 `type_id`、`type_name`、`input_mode`，保存當時的類型名稱與輸入方式；017 之前的紀錄歸為大盤。
- 只填箱數時，有包裝單位的原料記成「箱數 × 每箱數量」，零頭不計；**同樣會覆蓋帳面**。

需要先執行 016、017。**這版後端需要 018 才能盤點**，請先執行 018 再部署。

## 大單位＋小單位顯示、芒果假資料（019，尚未套用共用庫）

`019_inventory_display_by_pack.sql` 在 `inventory` 加上 `display_by_pack`（預設 FALSE）。設成 TRUE 的原料，畫面上的帳面、實點、差異、報廢數量改成「幾籃幾顆」顯示，資料庫照樣存基本單位數量（`per_pack` 換算後）。盤點時零散數量要少於 1 個包裝單位。

`per_pack` 建議填實際的平均數量，原料成本與差異金額才算得準。同一支檔案加入假資料「芒果」：1 籃 = 30 顆、帳面 153 顆（5 籃 3 顆）、安全庫存 60 顆（2 籃）、每顆 15 元。

**這版後端需要 019（`Inventory` 會讀 `display_by_pack`），請先執行 019 再部署。**

## 盤點一律整數（020，尚未套用共用庫）

`020_count_integer_only.sql` 拿掉 `inventory.allow_decimal`。盤點都是數包裝或數得出的個數，開封、用到一半的不算，所以實點數量一律只收整數，不再逐項設定。原料報廢、手動校正仍可填小數（報廢不改帳面，只是紀錄與損耗金額）。

需要先執行 016–019。這版後端不再讀 `allow_decimal`，020 執行前後都能運作。

## 配方改成材料清單、半成品（021，尚未套用共用庫）

`021_recipe_tables.sql`：

- **配方只記「用了哪些材料」**（`product_recipe`），不記份量；份量與做法寫在 `product.recipe_steps`（文字）。中杯、大杯共用同一份清單，紙杯不列入。拿掉 `product.recipe_json`。
- **半成品** `prep_item`（例如茶凍、紅茶湯）與它用了哪些原料 `prep_item_ingredient`。配方的每一列是原料或半成品其中一個。
- **加料** `topping` 可以指向原料或半成品；拿掉扣料量 `deduct_qty`。
- 原料「茶凍」改成半成品，配方與加料的茶凍都改指向半成品；原料「茶凍」若有盤點或報廢紀錄則保留（見檔案最後的核對查詢）。
- **點餐和配方分開**：點餐不讀配方，沒有配方的飲品照樣可以點；每杯不再計算原料成本（`order_item.material_cost` 之後為 NULL，舊訂單保留）。日結的損耗金額只加總原料報廢，飲品報廢只算杯數。
- `recipe_cost_report.sql` 已停用。

搬資料規則：舊 `recipe_json` 中、大杯都有的原料才列入（紙杯自然排除）；只有一種杯型的飲品則全部列入，可能含紙杯，請用核對查詢檢查。需要 009、016–020。**這版後端需要 021，請先執行 021 再部署。**

維護範例（目前只能用 SQL）：

```sql
-- 新增半成品「紅茶湯」，由紅茶包做成
INSERT INTO prep_item (name, steps) VALUES ('紅茶湯', '每桶 10 包茶包，煮 8 分鐘');
INSERT INTO prep_item_ingredient (prep_id, inventory_id)
SELECT p.prep_id, i.inventory_id FROM prep_item p, inventory i WHERE p.name = '紅茶湯' AND i.name = '紅茶包';
-- 茶凍拿鐵：紅茶湯（半成品）＋牛奶（原料）＋茶凍（半成品）
INSERT INTO product_recipe (product_id, prep_id, sort_order) SELECT 6, prep_id, 1 FROM prep_item WHERE name = '紅茶湯';
INSERT INTO product_recipe (product_id, inventory_id, sort_order) SELECT 6, inventory_id, 2 FROM inventory WHERE name = '牛奶';
INSERT INTO product_recipe (product_id, prep_id, sort_order) SELECT 6, prep_id, 3 FROM prep_item WHERE name = '茶凍';
```

